import csv,json,hashlib,re,io
from pathlib import Path
from zipfile import ZipFile
from collections import defaultdict,Counter,deque
from itertools import groupby
from datetime import datetime
R=Path(__file__).resolve().parents[1]
CUTOFF='2026-11-05'  # Inclusive check date; source timezone unspecified.
LEAGUES={'en.1':'England Premier League','de.1':'Germany Bundesliga','es.1':'Spain La Liga','it.1':'Italy Serie A','fr.1':'France Ligue 1'}
rows=[];manifest=[];rejected=[]
def add(league,season,day,home,away,ft,ht,path,source,round_name=''):
 if not day or not ft or len(ft)!=2 or any(type(x)!=int or x<0 for x in ft):
  rejected.append(dict(source_path=path,reason='unplayed_or_invalid_score',date=day));return
 datetime.strptime(day,'%Y-%m-%d')
 if day>CUTOFF:
  rejected.append(dict(source_path=path,reason='after_cutoff',date=day));return
 assert home!=away
 if not isinstance(ht,list) or len(ht)!=2 or any(type(x)!=int or x<0 for x in ht):ht=['','']
 if ht[0]!='' and any(a>b for a,b in zip(ht,ft)):
  rejected.append(dict(source_path=path,reason='invalid_halftime',date=day));ht=['','']
 h,a=ft
 key=f'{league}|{season}|{day}|{home}|{away}'
 rows.append(dict(match_id=hashlib.sha256(key.encode()).hexdigest()[:20],league=league,season=season,date=day,home_team=home,away_team=away,round=round_name,home_goals=h,away_goals=a,ht_home_goals=ht[0],ht_away_goals=ht[1],target_result='H' if h>a else 'A' if h<a else 'D',target_total_goals=h+a,target_over_2_5=int(h+a>=3),target_btts=int(h>0 and a>0),source=source,source_path=path))
for archive,repo in [('football-json.zip','openfootball/football.json'),('england.zip','footballcsv/england')]:
 with ZipFile(R/'raw'/archive) as z:
  assert z.testzip() is None
  manifest.append(dict(repository='https://github.com/'+repo,commit=z.comment.decode(),archive=archive,sha256=hashlib.sha256((R/'raw'/archive).read_bytes()).hexdigest()))
  (R/'raw'/('LICENSE_'+repo.replace('/','_')+'.md')).write_bytes(z.read(next(n for n in z.namelist() if n.endswith('/LICENSE.md'))))
  for n in z.namelist():
   if archive=='football-json.zip':
    league=n.split('/')[-1].removesuffix('.json')
    if league not in LEAGUES or not n.endswith('.json'):continue
    season=n.split('/')[-2];data=json.loads(z.read(n))
    for m in data['matches']:
     s=m.get('score',{});ft=s.get('ft') if isinstance(s,dict) else s
     ht=s.get('ht') if isinstance(s,dict) else None
     add(league,season,m.get('date'),m['team1'],m['team2'],ft,ht,n,repo,m.get('round',''))
   elif n.endswith('/eng.1.csv'):
    season=n.split('/')[-2]
    if season>='2010-11':continue  # No overlapping sources.
    for m in csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'))):
     ft=[int(x) for x in m['FT'].strip().split('-')] if re.fullmatch(r'\d+-\d+',m['FT'].strip()) else None
     day=datetime.strptime(m['Date'].strip(),'%a %b %d %Y').strftime('%Y-%m-%d')
     add('en.1',season,day,m['Team 1'].strip(),m['Team 2'].strip(),ft,None,n,repo,m.get('Round',''))
from supplement import merge
merge(rows, add, manifest, CUTOFF)
rows.sort(key=lambda r:(r['date'],r['league'],r['match_id']))
assert len({r['match_id'] for r in rows})==len(rows),'Duplicate matches'
def save(path,data,fields=None):
 with (R/path).open('w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields or list(data[0]));w.writeheader();w.writerows(data)
save('data/matches.csv',rows)
# Histories deliberately reset per league-season: no unverified cross-season name linking.
history=defaultdict(list);training=[]
for day,g in groupby(rows,key=lambda r:r['date']):
 batch=list(g)
 for r in batch:
  x={k:r[k] for k in ['match_id','league','season','date','home_team','away_team']}
  for side in ['home','away']:
   past=history[(r['league'],r['season'],r[side+'_team'])]
   x[side+'_prior_matches']=len(past)
   x[side+'_prior_points_per_game']=sum(p[0] for p in past)/len(past) if past else ''
   x[side+'_prior_goals_for_avg']=sum(p[1] for p in past)/len(past) if past else ''
   x[side+'_prior_goals_against_avg']=sum(p[2] for p in past)/len(past) if past else ''
   recent=past[-5:]
   x[side+'_last5_points_per_game']=sum(p[0] for p in recent)/len(recent) if recent else ''
  x.update({k:r[k] for k in ['target_result','target_total_goals','target_over_2_5','target_btts']})
  x['split']='train' if day<'2023-07-01' else 'validation' if day<'2024-07-01' else 'test'
  training.append(x)
 for r in batch:
  for side,other in [('home','away'),('away','home')]:
   gf,ga=r[side+'_goals'],r[other+'_goals']
   history[(r['league'],r['season'],r[side+'_team'])].append((3 if gf>ga else 1 if gf==ga else 0,gf,ga))
save('data/training.csv',training)
coverage=[]
groups=defaultdict(list)
for r in rows:groups[(r['league'],r['season'])].append(r)
for (league,season),ms in sorted(groups.items()):
 teams=sorted({r[s+'_team'] for r in ms for s in ['home','away']})
 pairs=Counter((r['home_team'],r['away_team']) for r in ms)
 missing=sum((h,a) not in pairs for h in teams for a in teams if h!=a)
 duplicated=sum(v-1 for v in pairs.values())
 status='complete_double_round_robin' if not missing and not duplicated else 'incomplete_or_special_format'
 if season=='2026-27':status='ongoing'
 if league=='fr.1' and season=='2019-20':status='officially_curtailed_season'
 coverage.append(dict(league=league,season=season,matches=len(ms),teams=len(teams),expected_double_round_robin=len(teams)*(len(teams)-1),missing_pairs=missing,duplicate_pairs=duplicated,first_date=min(r['date'] for r in ms),last_date=max(r['date'] for r in ms),halftime_available=sum(r['ht_home_goals']!='' for r in ms),status=status))
save('reports/coverage_by_season.csv',coverage)
(R/'reports/rejected.json').write_text(json.dumps(rejected,ensure_ascii=False,indent=2))
summary=dict(cutoff=CUTOFF,matches=len(rows),first_date=rows[0]['date'],last_date=rows[-1]['date'],leagues=dict(Counter(r['league'] for r in rows)),seasons=len(coverage),coverage_status=dict(Counter(r['status'] for r in coverage)),splits=dict(Counter(r['split'] for r in training)),sources=manifest,excluded_records=len(rejected))
(R/'reports/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False,indent=2))
complete={(r['league'],r['season']) for r in coverage if r['status']=='complete_double_round_robin'}
save('data/matches_complete_seasons.csv',[r for r in rows if (r['league'],r['season']) in complete])
save('data/training_complete_seasons.csv',[r for r in training if (r['league'],r['season']) in complete])
gaps=[]
for c in coverage:
 if c['status']!='incomplete_or_special_format':continue
 ms=groups[(c['league'],c['season'])];teams={r[s+'_team'] for r in ms for s in ['home','away']};pairs={(r['home_team'],r['away_team']) for r in ms}
 for h in sorted(teams):
  for a in sorted(teams):
   if h!=a and (h,a) not in pairs:gaps.append(dict(league=c['league'],season=c['season'],home_team=h,away_team=a))
save('reports/missing_historical_fixtures.csv',gaps,['league','season','home_team','away_team'])
print('Complete-season core:',sum((r['league'],r['season']) in complete for r in rows),'matches; historical gaps:',len(gaps))
