import csv,json
from pathlib import Path
from collections import defaultdict
R=Path(__file__).resolve().parents[1]
def read(p):return list(csv.DictReader((R/p).open()))
ms=read('data/matches.csv');ts=read('data/training.csv');byid={m['match_id']:m for m in ms}
assert len(ms)==len(byid)==len(ts)
history=defaultdict(list)
for m,t in zip(ms,ts):
 assert m['match_id']==t['match_id'] and m['date']<='2026-11-05'
 h,a=int(m['home_goals']),int(m['away_goals'])
 assert m['target_result']==('H' if h>a else 'A' if h<a else 'D')
 assert int(m['target_total_goals'])==h+a
 assert int(m['target_over_2_5'])==int(h+a>=3)
 assert int(m['target_btts'])==int(h>0 and a>0)
 for side,other in [('home','away'),('away','home')]:
  k=(m['league'],m['season'],m[side+'_team'])
  prior=[p for p in history[k] if p[0]<m['date']]
  assert int(t[side+'_prior_matches'])==len(prior)
  if prior:
   checks={'prior_points_per_game':sum(p[1] for p in prior)/len(prior),'prior_goals_for_avg':sum(p[2] for p in prior)/len(prior),'prior_goals_against_avg':sum(p[3] for p in prior)/len(prior),'last5_points_per_game':sum(p[1] for p in prior[-5:])/len(prior[-5:])}
   for name,v in checks.items():assert abs(float(t[side+'_'+name])-v)<1e-10
  else:assert t[side+'_prior_points_per_game']==''
  gf,ga=int(m[side+'_goals']),int(m[other+'_goals'])
  history[k].append((m['date'],3 if gf>ga else 1 if gf==ga else 0,gf,ga))
sets={s:{r['date'] for r in ts if r['split']==s} for s in ['train','validation','test']}
assert max(sets['train'])<min(sets['validation']) and max(sets['validation'])<min(sets['test'])
core=read('data/matches_complete_seasons.csv');groups=defaultdict(list)
for m in core:groups[(m['league'],m['season'])].append(m)
for g in groups.values():
 teams={m[s+'_team'] for m in g for s in ['home','away']};pairs={(m['home_team'],m['away_team']) for m in g}
 assert len(g)==len(pairs)==len(teams)*(len(teams)-1)
assert len(read('data/training_complete_seasons.csv'))==len(core)
print(f'PASS: {len(ms)} results and feature rows; chronological splits; historical-only features; {len(core)} core matches in {len(groups)} structurally complete seasons.')
