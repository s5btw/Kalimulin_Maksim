"""Merge only missing historical results and the current season; audit all overlaps."""
import csv,io,json,hashlib
from collections import defaultdict,Counter
from zipfile import ZipFile
from datetime import datetime
from pathlib import Path
R=Path(__file__).resolve().parents[1]
CURRENT={'ENG_1_premier-league':'en.1','GER_1_bundesliga':'de.1','ESP_1_la-liga':'es.1','ITA_1_serie-a':'it.1','FRA_1_ligue-1':'fr.1'}
FD={'E0':'en.1','D1':'de.1','SP1':'es.1','I1':'it.1','F1':'fr.1'}
def load(z,n):return list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'))))
def aliases(base,league,season,rs,source):
    votes=defaultdict(Counter)
    b=[m for m in base if (m['league'],m['season'])==(league,season)]
    for r in rs:
        for m in b:
            if (m['date'],int(m['home_goals']),int(m['away_goals']))==(r['date'],r['h'],r['a']):
                votes[r['home']][m['home_team']]+=1
                votes[r['away']][m['away_team']]+=1
    result={};evidence=[]
    for name in sorted({r[s] for r in rs for s in ['home','away']}):
        ranking=votes[name].most_common()
        assert ranking and ranking[0][1]>=2,(source,league,season,name,'insufficient overlap')
        assert len(ranking)==1 or ranking[0][1]>ranking[1][1],(name,ranking)
        result[name]=ranking[0][0]
        evidence.append(dict(source=source,league=league,season=season,source_name=name,canonical_name=result[name],supporting_observations=ranking[0][1],runner_up_observations=ranking[1][1] if len(ranking)>1 else 0))
    assert len(result)==len(set(result.values())), 'Non-bijective aliases'
    return result,evidence

def merge(rows,add,manifest,cutoff):
    original=len(rows);audit=[];mapping=[];added=[];upcoming=[]
    index={(m['league'],m['season'],m['home_team'],m['away_team']):m for m in rows}
    assert len(index)==len(rows)
    def ingest(league,season,rs,source):
        nonlocal index
        names,ev=aliases(rows,league,season,rs,source);mapping.extend(ev)
        for r in rs:
            if r['date']>cutoff:continue
            home,away=names[r['home']],names[r['away']]
            k=(league,season,home,away)
            if k in index:
                m=index[k]
                assert (m['date'],int(m['home_goals']),int(m['away_goals']))==(r['date'],r['h'],r['a']), ('Conflicting result',k,m,r)
                audit.append(dict(match_id=m['match_id'],source=source,path=r['path'],status='date_and_fulltime_agree'))
            else:
                add(league,season,r['date'],home,away,[r['h'],r['a']],r['ht'],r['path'],source,str(r.get('round','')))
                m=rows[-1];index[k]=m;added.append(dict(match_id=m['match_id'],league=league,season=season,date=r['date'],home_team=home,away_team=away,home_goals=r['h'],away_goals=r['a'],source=source,source_path=r['path']))
    def fdrows(rs,path):
        out=[]
        for r in rs:
            if not r.get('FTHG','').strip() or not r.get('FTAG','').strip():continue
            d=r['Date'].strip();day=datetime.strptime(d,'%d/%m/%Y' if len(d.split('/')[-1])==4 else '%d/%m/%y').strftime('%Y-%m-%d')
            ht=[int(r['HTHG']),int(r['HTAG'])] if r.get('HTHG','').isdigit() and r.get('HTAG','').isdigit() else None
            out.append(dict(date=day,home=r['HomeTeam'],away=r['AwayTeam'],h=int(r['FTHG']),a=int(r['FTAG']),ht=ht,path=path))
        return out
    for archive,repo in [('football-odds-mirror.zip','huhao930422-debug/football-odds-mirror'),('open-matchday.zip','oladeeayo/open-matchday'),('futbol-veri-deposu.zip','maparan1903-bit/futbol-veri-deposu')]:
        with ZipFile(R/'raw'/archive) as z:
            assert z.testzip() is None
            manifest.append(dict(repository='https://github.com/'+repo,commit=z.comment.decode(),archive=archive,sha256=hashlib.sha256((R/'raw'/archive).read_bytes()).hexdigest(),license='Upstream terms; not CC0'))
            if archive=='football-odds-mirror.zip':
                for folder,code,league,season in [('la-liga','2425','es.1','2024-25'),('serie-a','2425','it.1','2024-25'),('ligue-1','2526','fr.1','2025-26')]:
                    n=f'football-odds-mirror-main/data/{folder}/season-{code}.csv'
                    ingest(league,season,fdrows(load(z,n),n),repo)
                (R/'raw/football-odds-mirror_README.md').write_bytes(z.read('football-odds-mirror-main/README.md'))
            elif archive=='open-matchday.zip':
                for folder,league in CURRENT.items():
                    n=f'open-matchday-master/data/{folder}/results_2627.csv';rs=load(z,n)
                    parsed=[dict(date=r['date'],home=r['home'],away=r['away'],h=int(r['ft_home']),a=int(r['ft_away']),ht=[int(r['ht_home']),int(r['ht_away'])] if r['ht_home'].isdigit() and r['ht_away'].isdigit() else None,path=n,round=r['gw']) for r in rs]
                    ingest(league,'2026-27',parsed,repo)
                    fixtures=load(z,n.replace('results_','fixtures_'))
                    stale=[r for r in fixtures if r['date']<=cutoff]
                    upcoming.append(dict(league=league,latest_result=max(r['date'] for r in rs),result_count=len(rs),next_fixture=min(r['date'] for r in fixtures),unresolved_past_fixtures=stale))
                for f in ['DISCLAIMER.md','build_summary.json']:(R/'raw'/('open-matchday_'+f)).write_bytes(z.read('open-matchday-master/'+f))
            else:
                for code,league in FD.items():
                    n=f'futbol-veri-deposu-main/data/fd/2627/{code}.csv'
                    ingest(league,'2026-27',fdrows(load(z,n),n),repo)
    (R/'reports/added_results.json').write_text(json.dumps(added,ensure_ascii=False,indent=2))
    (R/'reports/alias_evidence.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2))
    (R/'reports/corroboration.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    (R/'reports/freshness.json').write_text(json.dumps(dict(checked_on='2026-11-05',snapshot_generated_utc='2026-11-04T05:38:04Z',original_matches=original,added_matches=len(added),current_leagues=upcoming,note='Agreement between public snapshots, not independent official verification. No scores invented for unplayed fixtures.'),ensure_ascii=False,indent=2))
